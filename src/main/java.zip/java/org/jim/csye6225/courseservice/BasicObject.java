package org.jim.csye6225.courseservice;

public abstract class BasicObject {
	public String id;
	
	public abstract String getId();
	public abstract void setId(String id);
}
